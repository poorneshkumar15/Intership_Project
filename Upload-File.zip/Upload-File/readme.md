To Upload an excel file to MongoDB database. Display the contents in a web page in a tabular format.

MongoDb imports data in CSV. 
Therefore, Excel template containing the user data is first converted to .csv format. 
The converted Employee data file is uploaded to MongoDB database.

The Uploaded data is displayed on a Web page in Tabular format. 
This data can be edited and deleted as per the users requirement for employee data.
The data edited and deleted is reflected onto the database.